const puppeteer = require('puppeteer');

const headless = process.argv[2] === "headless";

(async () => {
    const timeout = 30000
    const browser = await puppeteer.launch({
        headless: headless,
        timeout,
        args: ['--window-size=1360,768']
    });
    const page = await browser.newPage();
    await page.setViewport({ width: 1360, height: 768 })
	const label = "Go to Bing " + (headless?"without": "with") + " head."
	console.time(label)
    await page.goto("https://www.bing.com/", { timeout })
	const title = await page.title()
	console.log("Title: " + title);

 await page.waitForSelector("#scpt1");
    await page.click("#scpt1");
	const title3 = await page.title()
	console.log("Title: " + title3);

//await page.waitForSelector("#id_l");
 //   await page.click("#id_l");
 await page.goto("https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1543927185&rver=6.7.6631.0&wp=MBI_SSL&wreply=https%3a%2f%2fwww.bing.com%2fsecure%2fPassport.aspx%3frequrl%3dhttps%253a%252f%252fwww.bing.com%252fimages%252fdiscover%253fform%253dZ9LH1%2526wlexpsignin%253d1%26sig%3d2AA06EE108BD65CA3DE5625A09116414&lc=1033&id=264960&CSRFToken=356a1426-84c4-4218-93df-a03b4f9da47b&aadredir=1")
const title1 = await page.title()
	console.log("Title: " + title1);

await page.waitForSelector("#i0116");
await page.type("#i0116","testusername@test.com");

 await page.screenshot({path: '../screenshots/enteredValue.png'});
    //await page.waitForSelector("#id_l");
   // await page.click("#id_1");

   // await page.waitForSelector("#i0116");
   // await page.type("#i0116","testuserName");
//const title3= await page.title();
  //  console.log("Title: " + title3);
//await page.waitFor(4000);
	console.timeEnd(label);
    await browser.close();
})();